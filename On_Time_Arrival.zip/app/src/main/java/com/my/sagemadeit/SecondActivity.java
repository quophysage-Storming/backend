package com.my.sagemadeit;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.activity.EdgeToEdge;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.my.sagemadeit.databinding.*;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.regex.*;
import org.json.*;

public class SecondActivity extends AppCompatActivity {
	
	public final int REQ_CD_GLOGINAUTH = 101;
	
	private SecondBinding binding;
	GoogleSignInOptions gso;
	FirebaseUser users;
	
	private GoogleSignInClient gloginAuth;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	private Calendar cal = Calendar.getInstance();
	private SharedPreferences sp;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		EdgeToEdge.enable(this);
		binding = SecondBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		auth = FirebaseAuth.getInstance();
		sp = getSharedPreferences("sp", Activity.MODE_PRIVATE);
		
		binding.btnMain.setOnClickListener(_v -> {
			if (SketchwareUtil.isConnected(getApplicationContext())) {
				if (binding.etName.getText().toString().trim().equals("")) {
					binding.etName.setError("Enter your Name");
				} else {
					if (binding.etEmail.getText().toString().trim().equals("")) {
						binding.etEmail.setError("Enter your Gmail");
					} else {
						if (binding.etPassword.getText().toString().trim().equals("")) {
							binding.etPassword.setError("Enter your Password");
						} else {
							cal = Calendar.getInstance();
							auth.signInWithEmailAndPassword(binding.etName.getText().toString().concat(binding.etEmail.getText().toString().trim()), binding.etPassword.getText().toString().trim()).addOnCompleteListener(SecondActivity.this, _auth_sign_in_listener);
						}
					}
				}
			} else {
				SketchwareUtil.showMessage(getApplicationContext(), "no internet connection");
			}
		});
		
		binding.btnGoogle.setOnClickListener(_v -> {
			Intent signInIntent = gloginAuth.getSignInIntent();
			
			startActivityForResult(signInIntent, REQ_CD_GLOGINAUTH);
		});
		
		auth_updateEmailListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_updatePasswordListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_emailVerificationSentListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_deleteUserListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_phoneAuthListener = task -> {
			final boolean _success = task.isSuccessful();
			final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
			
		};
		
		auth_updateProfileListener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		auth_googleSignInListener = task -> {
			final boolean _success = task.isSuccessful();
			final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
			
		};
		
		_auth_create_user_listener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		_auth_sign_in_listener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
			
		};
		
		_auth_reset_password_listener = _param1 -> {
			final boolean _success = _param1.isSuccessful();
			
		};
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			Window window = getWindow();
			window.setNavigationBarColor(Color.parseColor("#00000000"));
			int flags = window.getDecorView().getSystemUiVisibility();
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
				flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
			}
			flags |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
			flags |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
			flags |= View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
			flags |= View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
			window.getDecorView().setSystemUiVisibility(flags);
		}
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		// ===================== SETTINGS =====================
		// true  = users must verify their email before they can use the app (Google users are already verified)
		// false = old behaviour (unverified users go straight to the dashboard)
		final boolean REQUIRE_VERIFIED_EMAIL = true;
		
		// Web client ID from google-services.json -> the "oauth_client" entry with "client_type": 3
		final String WEB_CLIENT_ID = "774830029636-4rupgmj06t3bbupt06haeou65hr3a1t6.apps.googleusercontent.com";
		// ====================================================
		
		// Already signed in? Skip the login screen and go straight to the dashboard.
		com.google.firebase.auth.FirebaseUser existing = com.google.firebase.auth.FirebaseAuth.getInstance().getCurrentUser();
		if (existing != null && (!REQUIRE_VERIFIED_EMAIL || existing.isEmailVerified())) {
			startActivity(new Intent(getApplicationContext(), DashActivity.class));
			finish();
			return;
		}
		
		setContentView(R.layout.second);
		setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
		getWindow().setStatusBarColor(Color.parseColor("#EAF5FF"));
		getWindow().setNavigationBarColor(Color.WHITE);
		getWindow().getDecorView().setSystemUiVisibility(
		View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
		
		final TextView heading = findViewById(R.id.heading);
		final TextView sub = findViewById(R.id.sub);
		final View wrapName = findViewById(R.id.wrap_name);
		final EditText etName = findViewById(R.id.et_name);
		final EditText etEmail = findViewById(R.id.et_email);
		final EditText etPass = findViewById(R.id.et_password);
		final TextView errName = findViewById(R.id.err_name);
		final TextView errEmail = findViewById(R.id.err_email);
		final TextView errPass = findViewById(R.id.err_password);
		final TextView toggle = findViewById(R.id.tv_toggle_pw);
		final TextView forgot = findViewById(R.id.tv_forgot);
		final TextView btnMain = findViewById(R.id.btn_main);
		final View btnGoogle = findViewById(R.id.btn_google);
		final TextView swQ = findViewById(R.id.tv_switch_q);
		final TextView swLink = findViewById(R.id.tv_switch_link);
		final TextView terms = findViewById(R.id.tv_terms);
		final boolean[] signup = {false};
		
		// FIX: hint now matches the real rule (8 characters minimum)
		etPass.setHint("At least 8 characters");
		
		final Runnable applyMode = new Runnable() {
			@Override public void run() {
				boolean up = signup[0];
				heading.setText(up ? "Create your account" : "Welcome back");
				sub.setText(up ? "Set up an account to send alerts from your school."
				: "Log in to send alerts to parents\u2019 phones.");
				wrapName.setVisibility(up ? View.VISIBLE : View.GONE);
				forgot.setVisibility(up ? View.GONE : View.VISIBLE);
				terms.setVisibility(View.VISIBLE);
				btnMain.setText(up ? "Create account" : "Log in");
				btnMain.setEnabled(true);
				swQ.setText(up ? "Already have an account?" : "New to On Time Arrival?");
				swLink.setText(up ? "Log in" : "Create account");
				errName.setVisibility(View.GONE);
				errEmail.setVisibility(View.GONE);
				errPass.setVisibility(View.GONE);
				etName.setBackgroundResource(R.drawable.bg_field);
				etEmail.setBackgroundResource(R.drawable.bg_field);
				etPass.setBackgroundResource(R.drawable.bg_field);
			}
		};
		applyMode.run();
		
		swLink.setOnClickListener(new View.OnClickListener() {
			@Override public void onClick(View v) { signup[0] = !signup[0]; applyMode.run(); }
		});
		
		toggle.setOnClickListener(new View.OnClickListener() {
			@Override public void onClick(View v) {
				boolean hidden = etPass.getTransformationMethod()
				instanceof android.text.method.PasswordTransformationMethod;
				etPass.setTransformationMethod(hidden
				? android.text.method.HideReturnsTransformationMethod.getInstance()
				: android.text.method.PasswordTransformationMethod.getInstance());
				etPass.setSelection(etPass.getText().length());
				toggle.setText(hidden ? "Hide" : "Show");
			}
		});
		
		// ---------- Firebase authentication ----------
		final com.google.firebase.auth.FirebaseAuth fa = com.google.firebase.auth.FirebaseAuth.getInstance();
		
		// Remember who signed in, then open the dashboard
		final Runnable goDash = new Runnable() {
			@Override public void run() {
				com.google.firebase.auth.FirebaseUser u = fa.getCurrentUser();
				String nm = "";
				String em = "";
				String pic = "";
				if (u != null) {
					if (u.getDisplayName() != null) nm = u.getDisplayName();
					if (u.getEmail() != null) em = u.getEmail();
					if (u.getPhotoUrl() != null) pic = u.getPhotoUrl().toString();
				}
				if (nm.length() == 0 && em.indexOf('@') > 0) nm = em.substring(0, em.indexOf('@'));
				getSharedPreferences("user_data", MODE_PRIVATE).edit()
				.putString("name", nm)
				.putString("email", em)
				.putString("profile", pic)
				.apply();
				startActivity(new Intent(getApplicationContext(), DashActivity.class));
				finish();
			}
		};
		
		// Shows Firebase errors on the matching field label of the screen
		class AuthUi {
			void showError(TextView err, View field, String msg) {
				err.setText(msg);
				err.setVisibility(View.VISIBLE);
				field.setBackgroundResource(R.drawable.bg_field_error);
			}
			void toast(String msg) {
				Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();
			}
			void fail(Exception e, boolean up) {
				applyMode.run();
				if (e instanceof com.google.firebase.FirebaseNetworkException) {
					toast("No internet connection. Check your network and try again.");
				} else if (e instanceof com.google.firebase.auth.FirebaseAuthUserCollisionException) {
					showError(errEmail, etEmail, "This email is already registered. Please log in.");
				} else if (e instanceof com.google.firebase.auth.FirebaseAuthWeakPasswordException) {
					showError(errPass, etPass, "Password is too weak. Use at least 8 characters.");
				} else if (e instanceof com.google.firebase.auth.FirebaseAuthInvalidUserException) {
					showError(errEmail, etEmail, "No account found with this email.");
				} else if (e instanceof com.google.firebase.auth.FirebaseAuthInvalidCredentialsException) {
					if (up) showError(errEmail, etEmail, "This email address is not valid.");
					else showError(errPass, etPass, "Incorrect email or password.");
				} else if (e instanceof com.google.firebase.FirebaseTooManyRequestsException) {
					toast("Too many attempts. Please try again later.");
				} else {
					// FIX: show the real reason so setup problems (e.g. provider disabled) are visible
					String why = (e != null && e.getMessage() != null) ? e.getMessage() : "unknown error";
					toast("Something went wrong: " + why);
				}
			}
		}
		final AuthUi ui = new AuthUi();
		
		// ---------- Log in / Create account button ----------
		btnMain.setOnClickListener(new View.OnClickListener() {
			@Override public void onClick(View v) {
				final boolean up = signup[0];
				final String nameTxt = etName.getText().toString().trim();
				final String emailTxt = etEmail.getText().toString().trim();
				final String passTxt = etPass.getText().toString();
				
				boolean okName = !up || nameTxt.length() > 1;
				boolean okEmail = android.util.Patterns.EMAIL_ADDRESS.matcher(emailTxt).matches();
				boolean okPass = passTxt.length() >= 8;
				
				errName.setText("Enter your full name");
				errEmail.setText("Enter a valid email address");
				errPass.setText("Use at least 8 characters");
				errName.setVisibility(okName ? View.GONE : View.VISIBLE);
				errEmail.setVisibility(okEmail ? View.GONE : View.VISIBLE);
				errPass.setVisibility(okPass ? View.GONE : View.VISIBLE);
				etName.setBackgroundResource(okName ? R.drawable.bg_field : R.drawable.bg_field_error);
				etEmail.setBackgroundResource(okEmail ? R.drawable.bg_field : R.drawable.bg_field_error);
				etPass.setBackgroundResource(okPass ? R.drawable.bg_field : R.drawable.bg_field_error);
				if (!(okName && okEmail && okPass)) return;
				
				btnMain.setEnabled(false);
				btnMain.setText("Please wait\u2026");
				
				if (up) {
					// Create account, save the full name, send verification email
					fa.createUserWithEmailAndPassword(emailTxt, passTxt)
					.addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<com.google.firebase.auth.AuthResult>() {
						@Override public void onComplete(com.google.android.gms.tasks.Task<com.google.firebase.auth.AuthResult> task) {
							if (!task.isSuccessful()) { ui.fail(task.getException(), true); return; }
							final com.google.firebase.auth.FirebaseUser cu = fa.getCurrentUser();
							if (cu == null) { applyMode.run(); return; }
							cu.updateProfile(new com.google.firebase.auth.UserProfileChangeRequest.Builder()
							.setDisplayName(nameTxt).build())
							.addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<Void>() {
								@Override public void onComplete(com.google.android.gms.tasks.Task<Void> t) {
									cu.sendEmailVerification()
									.addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<Void>() {
										@Override public void onComplete(com.google.android.gms.tasks.Task<Void> vt) {
											if (REQUIRE_VERIFIED_EMAIL) {
												// Send them back to the login screen until they verify
												fa.signOut();
												signup[0] = false;
												applyMode.run();
												etEmail.setText(emailTxt);
												if (vt.isSuccessful()) {
													ui.toast("Account created! We sent a verification link to " + emailTxt
													+ ". Verify it (check spam too), then log in.");
												} else {
													ui.toast("Account created, but the verification email could not be sent. Try logging in to resend it.");
												}
											} else {
												if (vt.isSuccessful()) {
													ui.toast("Account created! We sent a verification link to " + emailTxt
													+ ". Please check your inbox or spam folder.");
												} else {
													ui.toast("Account created, but we could not send the verification email. Please try again later.");
												}
												goDash.run();
											}
										}
									});
								}
							});
						}
					});
				} else {
					// Log in with email + password
					fa.signInWithEmailAndPassword(emailTxt, passTxt)
					.addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<com.google.firebase.auth.AuthResult>() {
						@Override public void onComplete(com.google.android.gms.tasks.Task<com.google.firebase.auth.AuthResult> task) {
							if (!task.isSuccessful()) { ui.fail(task.getException(), false); return; }
							final com.google.firebase.auth.FirebaseUser lu = fa.getCurrentUser();
							if (REQUIRE_VERIFIED_EMAIL && lu != null && !lu.isEmailVerified()) {
								// Not verified yet: resend the link, then sign out
								lu.sendEmailVerification()
								.addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<Void>() {
									@Override public void onComplete(com.google.android.gms.tasks.Task<Void> rt) {
										fa.signOut();
										applyMode.run();
										ui.toast("Please verify your email first. We sent a new link to " + emailTxt
										+ ". Check your inbox or spam folder.");
									}
								});
								return;
							}
							goDash.run();
						}
					});
				}
			}
		});
		
		// ---------- Continue with Google ----------
		final com.google.android.gms.auth.api.signin.GoogleSignInOptions gso =
		new com.google.android.gms.auth.api.signin.GoogleSignInOptions.Builder(
		com.google.android.gms.auth.api.signin.GoogleSignInOptions.DEFAULT_SIGN_IN)
		.requestIdToken(WEB_CLIENT_ID)
		.requestEmail()
		.build();
		final com.google.android.gms.auth.api.signin.GoogleSignInClient googleClient =
		com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(SecondActivity.this, gso);
		
		// Receives the result of the Google account chooser
		final androidx.activity.result.ActivityResultLauncher<Intent> googleLauncher =
		registerForActivityResult(
		new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
		new androidx.activity.result.ActivityResultCallback<androidx.activity.result.ActivityResult>() {
			@Override public void onActivityResult(androidx.activity.result.ActivityResult result) {
				com.google.android.gms.tasks.Task<com.google.android.gms.auth.api.signin.GoogleSignInAccount> acctTask =
				com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(result.getData());
				try {
					com.google.android.gms.auth.api.signin.GoogleSignInAccount acct =
					acctTask.getResult(com.google.android.gms.common.api.ApiException.class);
					String idToken = acct.getIdToken();
					if (idToken == null) {
						btnGoogle.setEnabled(true);
						ui.toast("Google sign-in failed: no ID token. Check the web client ID (client_type 3).");
						return;
					}
					com.google.firebase.auth.AuthCredential cred =
					com.google.firebase.auth.GoogleAuthProvider.getCredential(idToken, null);
					fa.signInWithCredential(cred)
					.addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<com.google.firebase.auth.AuthResult>() {
						@Override public void onComplete(com.google.android.gms.tasks.Task<com.google.firebase.auth.AuthResult> task) {
							if (task.isSuccessful()) {
								goDash.run();
							} else {
								btnGoogle.setEnabled(true);
								if (task.getException() instanceof com.google.firebase.FirebaseNetworkException) {
									ui.toast("No internet connection. Check your network and try again.");
								} else {
									ui.toast("Google sign-in failed. Make sure Google is enabled in Firebase Authentication.");
								}
							}
						}
					});
				} catch (com.google.android.gms.common.api.ApiException e) {
					btnGoogle.setEnabled(true);
					int code = e.getStatusCode();
					if (code == 12501) {
						ui.toast("Google sign-in cancelled.");
					} else if (code == 7) {
						ui.toast("No internet connection. Check your network and try again.");
					} else if (code == 10) {
						ui.toast("Google sign-in setup error (code 10). Add this build's SHA-1 in Firebase, re-import google-services.json, and rebuild.");
					} else if (code == 12500) {
						ui.toast("Google sign-in failed (code 12500). Set a support email and add the SHA-1 in Firebase.");
					} else {
						ui.toast("Google sign-in failed (code " + code + ").");
					}
				} catch (Exception e) {
					btnGoogle.setEnabled(true);
					ui.toast("Google sign-in failed. Please try again.");
				}
			}
		});
		
		btnGoogle.setOnClickListener(new View.OnClickListener() {
			@Override public void onClick(View v) {
				btnGoogle.setEnabled(false);
				// Sign out of the Google client first so the account chooser always appears
				googleClient.signOut().addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<Void>() {
					@Override public void onComplete(com.google.android.gms.tasks.Task<Void> t) {
						googleLauncher.launch(googleClient.getSignInIntent());
					}
				});
			}
		});
		
		// ---------- Forgot password ----------
		forgot.setOnClickListener(new View.OnClickListener() {
			@Override public void onClick(View v) {
				final String em = etEmail.getText().toString().trim();
				if (!android.util.Patterns.EMAIL_ADDRESS.matcher(em).matches()) {
					errEmail.setText("Type your email above, then tap Forgot password");
					errEmail.setVisibility(View.VISIBLE);
					etEmail.setBackgroundResource(R.drawable.bg_field_error);
					etEmail.requestFocus();
					return;
				}
				forgot.setEnabled(false);
				fa.sendPasswordResetEmail(em)
				.addOnCompleteListener(new com.google.android.gms.tasks.OnCompleteListener<Void>() {
					@Override public void onComplete(com.google.android.gms.tasks.Task<Void> t) {
						forgot.setEnabled(true);
						if (t.isSuccessful()) {
							ui.toast("Password reset link sent to " + em);
						} else if (t.getException() instanceof com.google.firebase.FirebaseNetworkException) {
							ui.toast("No internet connection. Check your network and try again.");
						} else if (t.getException() instanceof com.google.firebase.auth.FirebaseAuthInvalidUserException) {
							ui.showError(errEmail, etEmail, "No account found with this email.");
						} else {
							ui.toast("Could not send the reset email. Please try again.");
						}
					}
				});
			}
		});
		binding.heading.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_bold.ttf"), 1);
		binding.textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_bold.ttf"), 1);
		binding.textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_bold.ttf"), 1);
		binding.textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_bold.ttf"), 1);
		binding.textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_bold.ttf"), 1);
		binding.sub.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.tvForgot.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.tvTerms.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.btnMain.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.errName.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.etName.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.errEmail.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.etEmail.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.etPassword.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.errPassword.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.etPassword.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.errPassword.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.tvTogglePw.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.tvSwitchQ.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.tvSwitchLink.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_GLOGINAUTH:
			if (_resultCode == Activity.RESULT_OK) {
				Task<GoogleSignInAccount> _task = GoogleSignIn.getSignedInAccountFromIntent(_data);
				
				try {
					// Google Sign In was successful, authenticate with Firebase
					GoogleSignInAccount account = _task.getResult(ApiException.class);
					
					firebaseAuthWithGoogle(account.getIdToken());
				} catch (ApiException e) {
					//On Fiailure
					final String ErrorOnResultSign = e.getMessage();
					SketchwareUtil.showMessage(getApplicationContext(), "Google sign-in failed. Please try again.");
				}
			}
			else {
				SketchwareUtil.showMessage(getApplicationContext(), "cancelled");
			}
			break;
			default:
			break;
		}
	}
	
	public void _signInWithGoogle() {
	}
	private void firebaseAuthWithGoogle(String idToken) {
		AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
		auth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
			
			@Override
			public void onComplete(@NonNull Task<AuthResult> task) {
				if (task.isSuccessful()) {
					users = auth.getCurrentUser();
					i.setClass(getApplicationContext(), DashActivity.class);
					sp.edit().putString("name", users.getDisplayName()).commit();
					sp.edit().putString("profile", users.getPhotoUrl().toString()).commit();
					startActivity(i);
					finish();
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "Login Not successful");
				}
			}
		});
	}
	//[END auth_with_google]
	{
	}
	
}