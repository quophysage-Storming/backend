package com.my.sagemadeit;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.activity.EdgeToEdge;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.my.sagemadeit.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import android.animation.ValueAnimator;
import android.graphics.drawable.GradientDrawable;
import android.graphics.PorterDuff;
import android.content.pm.ActivityInfo;
import android.view.animation.OvershootInterpolator;
import android.view.MotionEvent;


public class MainActivity extends AppCompatActivity {
	
	private MainBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		EdgeToEdge.enable(this);
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
	}
	
	private void initializeLogic() {
		// ---------- 0. Skip onboarding if already completed ----------
		final android.content.SharedPreferences onboardingPrefs =
		getSharedPreferences("app_preferences", MODE_PRIVATE);
		if (onboardingPrefs.getBoolean("onboarding_completed", false)) {
			startActivity(new Intent(getApplicationContext(), SecondActivity.class));
			finish();
			return;
		}
		
		// ---------- 1. Window: transparent bars, edge-to-edge ----------
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		{
			Window window = getWindow();
			window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			window.setStatusBarColor(Color.TRANSPARENT);
			window.setNavigationBarColor(Color.TRANSPARENT);
			int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
			| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
			| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
			| View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
			if (Build.VERSION.SDK_INT >= 23) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
			window.getDecorView().setSystemUiVisibility(flags);
		}
		
		// ---------- 2. YOUR CONTENT: change photos / texts / colors here ----------
		final int[] images = { R.drawable.image1_no_bg_1, R.drawable.image1_no_bg_3,
			R.drawable.image1_no_bg_2, R.drawable.image1_no_bg_4 };
		final String[] titles = {
			"Know they arrived safely", "Attendance, the moment it’s marked",
			"Never miss what matters", "Every school update, one tap away" };
		final String[] infos = {
			"Send instant alert to parent phone as soon as their child reaches school, so they never have to wonder.",
			"Let parents see right away if their child is present, late or absent.",
			"Alert every parent about early closing, holidays and re-opening dates.",
			"Announcements, reminders and urgent notices all land on parents phone. Set up takes less than a minute." };
		final int[] accents = { Color.parseColor("#40A8F6"), Color.parseColor("#8B7CF6"),
			Color.parseColor("#FF9F43"), Color.parseColor("#22C98F") };
		final int[] tints   = { Color.parseColor("#EAF5FF"), Color.parseColor("#F1EEFF"),
			Color.parseColor("#FFF3E5"), Color.parseColor("#E6FAF2") };
		final boolean AUTO_PLAY = true;
		final int AUTO_MS = 5000;
		
		// ---------- 3. Metrics & state ----------
		final android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
		final int SW = dm.widthPixels;
		final int SH = dm.heightPixels;
		final float d = dm.density;
		int sbRes = getResources().getIdentifier("status_bar_height", "dimen", "android");
		final int SB = sbRes > 0 ? getResources().getDimensionPixelSize(sbRes) : (int) (28 * d);
		
		final int LAST = images.length - 1;
		final int DOT_OFF = Color.parseColor("#D9DEE7");
		final int[] page = {0};
		final int[] target = {0};
		final int[] curAccent = {accents[0]};
		final int[] curTint = {tints[0]};
		final long[] lastClick = {0};
		final Runnable[] go = new Runnable[1];
		final Runnable[] auto = new Runnable[1];
		
		// ---------- 4. Build the UI ----------
		final FrameLayout rootLayout = new FrameLayout(this);
		rootLayout.setBackgroundColor(tints[0]);
		
		// decorative blobs
		final GradientDrawable blob1 = new GradientDrawable();
		blob1.setShape(GradientDrawable.OVAL);
		blob1.setColor((accents[0] & 0x00FFFFFF) | 0x33000000);
		View blobView1 = new View(this);
		blobView1.setBackground(blob1);
		FrameLayout.LayoutParams lpB1 = new FrameLayout.LayoutParams((int) (SW * 0.85f), (int) (SW * 0.85f));
		lpB1.gravity = Gravity.TOP | Gravity.END;
		lpB1.topMargin = (int) (SB + 20 * d - SW * 0.25f);
		lpB1.rightMargin = (int) (-SW * 0.25f);
		rootLayout.addView(blobView1, lpB1);
		
		final GradientDrawable blob2 = new GradientDrawable();
		blob2.setShape(GradientDrawable.OVAL);
		blob2.setColor((accents[0] & 0x00FFFFFF) | 0x22000000);
		View blobView2 = new View(this);
		blobView2.setBackground(blob2);
		FrameLayout.LayoutParams lpB2 = new FrameLayout.LayoutParams((int) (SW * 0.5f), (int) (SW * 0.5f));
		lpB2.gravity = Gravity.TOP | Gravity.START;
		lpB2.topMargin = (int) (SH * 0.33f);
		lpB2.leftMargin = (int) (-SW * 0.18f);
		rootLayout.addView(blobView2, lpB2);
		
		// photo area
		int imgAreaH = (int) (SH * 0.50f);
		FrameLayout imageHolder = new FrameLayout(this);
		FrameLayout.LayoutParams lpHolder = new FrameLayout.LayoutParams(SW, imgAreaH);
		lpHolder.gravity = Gravity.TOP;
		lpHolder.topMargin = SB + (int) (56 * d);
		rootLayout.addView(imageHolder, lpHolder);
		
		int circleSize = (int) Math.min(SW * 0.78f, imgAreaH * 0.92f);
		GradientDrawable whiteCircle = new GradientDrawable();
		whiteCircle.setShape(GradientDrawable.OVAL);
		whiteCircle.setColor(0x99FFFFFF);
		View circleView = new View(this);
		circleView.setBackground(whiteCircle);
		FrameLayout.LayoutParams lpCircle = new FrameLayout.LayoutParams(circleSize, circleSize);
		lpCircle.gravity = Gravity.CENTER;
		imageHolder.addView(circleView, lpCircle);
		
		final FrameLayout floatHolder = new FrameLayout(this);
		imageHolder.addView(floatHolder, new FrameLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		final ImageView imgView = new ImageView(this);
		imgView.setScaleType(ImageView.ScaleType.FIT_CENTER);
		imgView.setAdjustViewBounds(true);
		int ip = (int) (14 * d);
		imgView.setPadding(ip, ip, ip, ip);
		imgView.setImageResource(images[0]);
		floatHolder.addView(imgView, new FrameLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		
		final android.animation.ObjectAnimator floatAnim =
		android.animation.ObjectAnimator.ofFloat(floatHolder, "translationY", 0f, -10 * d);
		floatAnim.setDuration(2200);
		floatAnim.setRepeatCount(android.animation.ValueAnimator.INFINITE);
		floatAnim.setRepeatMode(android.animation.ValueAnimator.REVERSE);
		floatAnim.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
		floatAnim.start();
		
		// skip pill
		final TextView skipBtn = new TextView(this);
		skipBtn.setText("Skip");
		skipBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
		skipBtn.setTypeface(Typeface.DEFAULT_BOLD);
		skipBtn.setTextColor(Color.parseColor("#4B5563"));
		skipBtn.setPadding((int) (18 * d), (int) (9 * d), (int) (18 * d), (int) (9 * d));
		GradientDrawable skipBg = new GradientDrawable();
		skipBg.setCornerRadius(24 * d);
		skipBg.setColor(0xCCFFFFFF);
		skipBtn.setBackground(skipBg);
		skipBtn.setVisibility(View.GONE);
		FrameLayout.LayoutParams lpSkip = new FrameLayout.LayoutParams(
		ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lpSkip.gravity = Gravity.TOP | Gravity.END;
		lpSkip.topMargin = SB + (int) (12 * d);
		lpSkip.rightMargin = (int) (20 * d);
		rootLayout.addView(skipBtn, lpSkip);
		
		// bottom card
		LinearLayout card = new LinearLayout(this);
		card.setOrientation(LinearLayout.VERTICAL);
		GradientDrawable cardBg = new GradientDrawable();
		float cr = 36 * d;
		cardBg.setCornerRadii(new float[]{cr, cr, cr, cr, 0, 0, 0, 0});
		cardBg.setColor(Color.WHITE);
		card.setBackground(cardBg);
		card.setElevation(20 * d);
		card.setPadding((int) (28 * d), (int) (26 * d), (int) (28 * d), (int) (32 * d));
		FrameLayout.LayoutParams lpCard = new FrameLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lpCard.gravity = Gravity.BOTTOM;
		rootLayout.addView(card, lpCard);
		
		// row: dots + counter
		LinearLayout topRow = new LinearLayout(this);
		topRow.setOrientation(LinearLayout.HORIZONTAL);
		topRow.setGravity(Gravity.CENTER_VERTICAL);
		card.addView(topRow, new LinearLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		
		LinearLayout dotsBox = new LinearLayout(this);
		dotsBox.setOrientation(LinearLayout.HORIZONTAL);
		dotsBox.setGravity(Gravity.CENTER_VERTICAL);
		topRow.addView(dotsBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
		
		final View[] dots = new View[images.length];
		final GradientDrawable[] dotBg = new GradientDrawable[images.length];
		for (int i = 0; i < images.length; i++) {
			dots[i] = new View(this);
			dotBg[i] = new GradientDrawable();
			dotBg[i].setCornerRadius(4 * d);
			dotBg[i].setColor(i == 0 ? accents[0] : DOT_OFF);
			dots[i].setBackground(dotBg[i]);
			LinearLayout.LayoutParams lpDot = new LinearLayout.LayoutParams(
			(int) ((i == 0 ? 28 : 8) * d), (int) (8 * d));
			lpDot.rightMargin = (int) (6 * d);
			dotsBox.addView(dots[i], lpDot);
		}
		
		final TextView counterTv = new TextView(this);
		counterTv.setText(String.format("%02d / %02d", 1, images.length));
		counterTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
		counterTv.setTypeface(Typeface.DEFAULT_BOLD);
		counterTv.setTextColor(accents[0]);
		topRow.addView(counterTv, new LinearLayout.LayoutParams(
		ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		
		// title
		final TextView titleTv = new TextView(this);
		titleTv.setText(titles[0]);
		titleTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 27);
		titleTv.setTypeface(Typeface.DEFAULT_BOLD);
		titleTv.setTextColor(Color.parseColor("#14213D"));
		LinearLayout.LayoutParams lpTitle = new LinearLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lpTitle.topMargin = (int) (20 * d);
		card.addView(titleTv, lpTitle);
		
		// description
		final TextView infoTv = new TextView(this);
		infoTv.setText(infos[0]);
		infoTv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
		infoTv.setTextColor(Color.parseColor("#6B7280"));
		infoTv.setLineSpacing(4 * d, 1f);
		infoTv.setMinLines(3);
		LinearLayout.LayoutParams lpInfo = new LinearLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lpInfo.topMargin = (int) (10 * d);
		card.addView(infoTv, lpInfo);
		
		// buttons row
		LinearLayout btnRow = new LinearLayout(this);
		btnRow.setOrientation(LinearLayout.HORIZONTAL);
		btnRow.setGravity(Gravity.CENTER_VERTICAL);
		LinearLayout.LayoutParams lpBtnRow = new LinearLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lpBtnRow.topMargin = (int) (26 * d);
		card.addView(btnRow, lpBtnRow);
		
		// back button (round)
		final LinearLayout backBtn = new LinearLayout(this);
		backBtn.setGravity(Gravity.CENTER);
		GradientDrawable backBg = new GradientDrawable();
		backBg.setShape(GradientDrawable.OVAL);
		backBg.setColor(Color.WHITE);
		backBg.setStroke((int) (1.5f * d), Color.parseColor("#E5E7EB"));
		backBtn.setBackground(new android.graphics.drawable.RippleDrawable(
		android.content.res.ColorStateList.valueOf(0x22000000), backBg, null));
		ImageView backIcon = new ImageView(this);
		backIcon.setImageResource(R.drawable.next);
		backIcon.setRotation(180f);
		backIcon.setColorFilter(Color.parseColor("#14213D"), PorterDuff.Mode.SRC_IN);
		backBtn.addView(backIcon, new LinearLayout.LayoutParams((int) (20 * d), (int) (20 * d)));
		LinearLayout.LayoutParams lpBack = new LinearLayout.LayoutParams((int) (56 * d), (int) (56 * d));
		lpBack.rightMargin = (int) (12 * d);
		backBtn.setVisibility(View.GONE);
		btnRow.addView(backBtn, lpBack);
		
		// next button (pill)
		final FrameLayout nextBtn = new FrameLayout(this);
		final GradientDrawable nextBg = new GradientDrawable();
		nextBg.setCornerRadius(28 * d);
		nextBg.setColor(accents[0]);
		nextBtn.setBackground(new android.graphics.drawable.RippleDrawable(
		android.content.res.ColorStateList.valueOf(0x33FFFFFF), nextBg, null));
		final LinearLayout nextContent = new LinearLayout(this);
		nextContent.setOrientation(LinearLayout.HORIZONTAL);
		nextContent.setGravity(Gravity.CENTER_VERTICAL);
		final TextView nextText = new TextView(this);
		nextText.setText("Next");
		nextText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
		nextText.setTypeface(Typeface.DEFAULT_BOLD);
		nextText.setTextColor(Color.WHITE);
		nextContent.addView(nextText, new LinearLayout.LayoutParams(
		ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
		final ImageView nextIcon = new ImageView(this);
		nextIcon.setImageResource(R.drawable.next);
		nextIcon.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
		LinearLayout.LayoutParams lpNextIcon = new LinearLayout.LayoutParams((int) (18 * d), (int) (18 * d));
		lpNextIcon.leftMargin = (int) (8 * d);
		nextContent.addView(nextIcon, lpNextIcon);
		FrameLayout.LayoutParams lpNextContent = new FrameLayout.LayoutParams(
		ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
		lpNextContent.gravity = Gravity.CENTER;
		nextBtn.addView(nextContent, lpNextContent);
		btnRow.addView(nextBtn, new LinearLayout.LayoutParams(0, (int) (56 * d), 1f));
		
		setContentView(rootLayout);
		
		// ---------- 5. Finish onboarding ----------
		final Runnable finishOnboarding = new Runnable() {
			@Override public void run() {
				rootLayout.removeCallbacks(auto[0]);
				floatAnim.cancel();
				onboardingPrefs.edit().putBoolean("onboarding_completed", true).apply();
				startActivity(new Intent(getApplicationContext(), SecondActivity.class));
				finish();
				overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
			}
		};
		
		// ---------- 6. Page change ----------
		go[0] = new Runnable() {
			@Override public void run() {
				final int from = page[0];
				final int to = target[0];
				if (to == from || to < 0 || to > LAST) return;
				long now = System.currentTimeMillis();
				if (now - lastClick[0] < 450) return;
				lastClick[0] = now;
				page[0] = to;
				
				final boolean nowLast = (to == LAST);
				final boolean wasLast = (from == LAST);
				final float dir = to > from ? -1f : 1f;
				
				// colors + dots
				final int fromA = curAccent[0], toA = accents[to];
				final int fromT = curTint[0], toT = tints[to];
				curAccent[0] = toA;
				curTint[0] = toT;
				final android.animation.ArgbEvaluator ev = new android.animation.ArgbEvaluator();
				android.animation.ValueAnimator va = android.animation.ValueAnimator.ofFloat(0f, 1f);
				va.setDuration(380);
				va.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
					@Override public void onAnimationUpdate(android.animation.ValueAnimator a) {
						float t = (Float) a.getAnimatedValue();
						int ac = (Integer) ev.evaluate(t, fromA, toA);
						int tc = (Integer) ev.evaluate(t, fromT, toT);
						rootLayout.setBackgroundColor(tc);
						blob1.setColor((ac & 0x00FFFFFF) | 0x33000000);
						blob2.setColor((ac & 0x00FFFFFF) | 0x22000000);
						nextBg.setColor(ac);
						counterTv.setTextColor(ac);
						dotBg[to].setColor(ac);
						dotBg[from].setColor((Integer) ev.evaluate(t, fromA, DOT_OFF));
						dots[to].getLayoutParams().width = (int) ((8 + 20 * t) * d);
						dots[from].getLayoutParams().width = (int) ((28 - 20 * t) * d);
						dots[to].requestLayout();
						dots[from].requestLayout();
					}
				});
				va.start();
				
				counterTv.setText(String.format("%02d / %02d", to + 1, images.length));
				
				// photo
				imgView.animate().translationX(dir * SW * 0.35f).alpha(0f).scaleX(0.9f).scaleY(0.9f)
				.setDuration(220)
				.setInterpolator(new android.view.animation.AccelerateInterpolator())
				.withEndAction(new Runnable() {
					@Override public void run() {
						imgView.setImageResource(images[to]);
						imgView.setTranslationX(-dir * SW * 0.35f);
						imgView.animate().translationX(0f).alpha(1f).scaleX(1f).scaleY(1f)
						.setDuration(420)
						.setInterpolator(new android.view.animation.OvershootInterpolator(0.8f))
						.start();
					}
				}).start();
				
				// title
				titleTv.animate().alpha(0f).translationY(12 * d).setDuration(180)
				.withEndAction(new Runnable() {
					@Override public void run() {
						titleTv.setText(titles[to]);
						titleTv.setTranslationY(14 * d);
						titleTv.animate().alpha(1f).translationY(0f).setDuration(280).start();
					}
				}).start();
				
				// description
				infoTv.animate().alpha(0f).translationY(12 * d).setDuration(180)
				.withEndAction(new Runnable() {
					@Override public void run() {
						infoTv.setText(infos[to]);
						infoTv.setTranslationY(14 * d);
						infoTv.animate().alpha(1f).translationY(0f).setDuration(280)
						.setStartDelay(60).start();
					}
				}).start();
				
				// back button
				if (to == 0) {
					backBtn.setVisibility(View.GONE);
				} else if (from == 0) {
					backBtn.setAlpha(0f);
					backBtn.setScaleX(0.6f);
					backBtn.setScaleY(0.6f);
					backBtn.setVisibility(View.VISIBLE);
					backBtn.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).start();
				}
				
				// next button label (Next <-> Get Started)
				if (nowLast != wasLast) {
					nextContent.animate().alpha(0f).setDuration(120)
					.withEndAction(new Runnable() {
						@Override public void run() {
							nextText.setText(nowLast ? "Get Started" : "Next");
							nextIcon.setImageResource(nowLast ? R.drawable.img : R.drawable.next);
							nextContent.animate().alpha(1f).setDuration(180).start();
						}
					}).start();
				}
				
				// skip
				if (nowLast) {
					skipBtn.animate().alpha(0f).setDuration(200)
					.withEndAction(new Runnable() {
						@Override public void run() { skipBtn.setVisibility(View.GONE); }
					}).start();
				} else if (skipBtn.getVisibility() == View.VISIBLE) {
					skipBtn.setAlpha(1f);
				}
				
				// auto-play timer
				rootLayout.removeCallbacks(auto[0]);
				if (AUTO_PLAY && !nowLast) rootLayout.postDelayed(auto[0], AUTO_MS);
			}
		};
		
		// ---------- 7. Auto-play ----------
		auto[0] = new Runnable() {
			@Override public void run() {
				if (page[0] >= LAST) return;
				target[0] = page[0] + 1;
				go[0].run();
			}
		};
		if (AUTO_PLAY) rootLayout.postDelayed(auto[0], AUTO_MS);
		
		// ---------- 8. Skip appears after 1s ----------
		rootLayout.postDelayed(new Runnable() {
			@Override public void run() {
				if (page[0] == LAST) return;
				skipBtn.setAlpha(0f);
				skipBtn.setVisibility(View.VISIBLE);
				skipBtn.animate().alpha(1f).setDuration(400).start();
			}
		}, 1000);
		
		// ---------- 9. Buttons ----------
		nextBtn.setOnClickListener(new View.OnClickListener() {
			@Override public void onClick(View v) {
				if (page[0] == LAST) {
					finishOnboarding.run();
				} else {
					target[0] = page[0] + 1;
					go[0].run();
				}
			}
		});
		backBtn.setOnClickListener(new View.OnClickListener() {
			@Override public void onClick(View v) {
				target[0] = page[0] - 1;
				go[0].run();
			}
		});
		skipBtn.setOnClickListener(new View.OnClickListener() {
			@Override public void onClick(View v) { finishOnboarding.run(); }
		});
		
		// ---------- 10. Swipe left / right ----------
		final GestureDetector swipe = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
			@Override public boolean onDown(MotionEvent e) { return true; }
			@Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
				if (e1 == null || e2 == null) return false;
				float dx = e2.getX() - e1.getX();
				float dy = e2.getY() - e1.getY();
				if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 100 * d && Math.abs(vx) > 600) {
					if (dx < 0) {
						if (page[0] < LAST) { target[0] = page[0] + 1; go[0].run(); }
					} else {
						if (page[0] > 0) { target[0] = page[0] - 1; go[0].run(); }
					}
					return true;
				}
				return false;
			}
		});
		rootLayout.setOnTouchListener(new View.OnTouchListener() {
			@Override public boolean onTouch(View v, MotionEvent e) {
				swipe.onTouchEvent(e);
				if (e.getAction() == MotionEvent.ACTION_DOWN) {
					rootLayout.removeCallbacks(auto[0]);
				} else if (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL) {
					rootLayout.removeCallbacks(auto[0]);
					if (AUTO_PLAY && page[0] < LAST) rootLayout.postDelayed(auto[0], AUTO_MS);
				}
				return true;
			}
		});
	}
	
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float) _round);
		GG.setStroke((int) _stroke, Color.parseColor("#" + _strokeclr.replace("#", "")));
		_view.setElevation(0f);
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(
		new android.content.res.ColorStateList(
		new int[][]{ new int[]{} }, 
		new int[]{ Color.parseColor("#22000000") }
		), 
		GG,  
		null 
		);
		_view.setBackground(RE);
	}
	
}