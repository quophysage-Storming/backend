package com.my.sagemadeit;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import androidx.activity.EdgeToEdge;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.my.sagemadeit.databinding.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class DashActivity extends AppCompatActivity {
	
	private DashBinding binding;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		EdgeToEdge.enable(this);
		binding = DashBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		binding.linear18.setOnClickListener(_v -> {
			// ---- 1) Read and check the fields ----
			final com.google.android.material.textfield.TextInputLayout tilSchool = findViewById(R.id.textinputlayout5);
			final com.google.android.material.textfield.TextInputLayout tilPhone = findViewById(R.id.textinputlayout6);
			final com.google.android.material.textfield.TextInputLayout tilKid = findViewById(R.id.textinputlayout7);
			
			final String school = ((EditText) findViewById(R.id.edittext4)).getText().toString().trim();
			final String phone = ((EditText) findViewById(R.id.edittext5)).getText().toString().trim();
			final String kid = ((EditText) findViewById(R.id.edittext6)).getText().toString().trim();
			
			tilSchool.setError(school.length() < 2 ? "Enter the school name" : null);
			tilPhone.setError(phone.length() < 7 ? "Enter the parent\u2019s phone number" : null);
			tilKid.setError(kid.length() < 2 ? "Enter the child\u2019s name" : null);
			if (school.length() < 2 || phone.length() < 7 || kid.length() < 2) return;
			
			// ---- 2) Build the QR image (child's name is inside the QR data and printed under it) ----
			final android.graphics.Bitmap qrImage;
			try {
				org.json.JSONObject o = new org.json.JSONObject();
				o.put("kid", kid);
				o.put("phone", phone);
				o.put("school", school);
				
				java.util.Map<com.google.zxing.EncodeHintType, Object> hints = new java.util.HashMap<>();
				hints.put(com.google.zxing.EncodeHintType.CHARACTER_SET, "UTF-8");
				hints.put(com.google.zxing.EncodeHintType.MARGIN, 1);
				hints.put(com.google.zxing.EncodeHintType.ERROR_CORRECTION,
				com.google.zxing.qrcode.decoder.ErrorCorrectionLevel.M);
				
				final int S = 800;
				com.google.zxing.common.BitMatrix m = new com.google.zxing.qrcode.QRCodeWriter()
				.encode(o.toString(), com.google.zxing.BarcodeFormat.QR_CODE, S, S, hints);
				int[] px = new int[S * S];
				for (int y = 0; y < S; y++)
				for (int x = 0; x < S; x++)
				px[y * S + x] = m.get(x, y) ? 0xFF14213D : 0xFFFFFFFF;      // navy modules on white
				android.graphics.Bitmap qr = android.graphics.Bitmap.createBitmap(S, S, android.graphics.Bitmap.Config.ARGB_8888);
				qr.setPixels(px, 0, S, 0, 0, S, S);
				
				qrImage = android.graphics.Bitmap.createBitmap(S, S + 120, android.graphics.Bitmap.Config.ARGB_8888);
				android.graphics.Canvas cv = new android.graphics.Canvas(qrImage);
				cv.drawColor(Color.WHITE);
				cv.drawBitmap(qr, 0, 0, null);
				
				android.text.TextPaint tp = new android.text.TextPaint(android.graphics.Paint.ANTI_ALIAS_FLAG);
				tp.setColor(0xFF14213D);
				tp.setTextSize(58);
				tp.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
				tp.setTextAlign(android.graphics.Paint.Align.CENTER);
				CharSequence shown = android.text.TextUtils.ellipsize(kid, tp, S - 60, android.text.TextUtils.TruncateAt.END);
				cv.drawText(shown.toString(), S / 2f, S + 75, tp);
			} catch (Exception e) {
				Toast.makeText(getApplicationContext(), "Could not create the QR code: " + e, Toast.LENGTH_LONG).show();
				return;
			}
			
			// ---- 3) Close the keyboard ----
			android.view.inputmethod.InputMethodManager imm =
			(android.view.inputmethod.InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
			
			// ---- 4) Open the sheet and put the QR in imageview2 ----
			getWindow().getDecorView().postDelayed(new Runnable() {
				@Override public void run() {
					try {
						final com.google.android.material.bottomsheet.BottomSheetDialog dlg =
						new com.google.android.material.bottomsheet.BottomSheetDialog(DashActivity.this);
						final View sheet = getLayoutInflater().inflate(R.layout.qr_btsheet, null);
						dlg.setContentView(sheet);
						((View) sheet.getParent()).setBackgroundColor(Color.TRANSPARENT);   // keeps the rounded top corners
						
						dlg.getWindow().setSoftInputMode(
						WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
						| WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
						
						((ImageView) sheet.findViewById(R.id.imageview2)).setImageBitmap(qrImage);
						TextView meta = sheet.findViewById(R.id.tv_kid_meta);
						if (meta != null) meta.setText(school + "  \u2022  " + phone);
						
						View done = sheet.findViewById(R.id.btn_sheet_done);
						if (done != null) {
							done.setClickable(true);
							done.setOnClickListener(new View.OnClickListener() {
								@Override public void onClick(View x) { dlg.dismiss(); }
							});
						}
						// new FontApplier().apply(sheet);   // uncomment if you use FontSetup.java
						
						dlg.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
							@Override public void onShow(android.content.DialogInterface d) {
								com.google.android.material.bottomsheet.BottomSheetBehavior<View> b =
								com.google.android.material.bottomsheet.BottomSheetBehavior.from((View) sheet.getParent());
								b.setSkipCollapsed(true);
								b.setState(com.google.android.material.bottomsheet.BottomSheetBehavior.STATE_EXPANDED);
							}
						});
						dlg.show();
					} catch (Exception e) {
						Toast.makeText(getApplicationContext(), "Sheet error: " + e, Toast.LENGTH_LONG).show();
					}
				}
			}, 200);
		});
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			Window window = getWindow();
			window.setNavigationBarColor(Color.parseColor("#00000000"));
			int flags = window.getDecorView().getSystemUiVisibility();
			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
				flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
			}
			flags |= View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
			flags |= View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
			flags |= View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
			flags |= View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
			window.getDecorView().setSystemUiVisibility(flags);
		}
		getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
		// ============ Runtime location permission ============
		// Put this in DashActivity onCreate (Add source directly / initializeLogic). It asks for location as soon as the dashboard opens.
		// Also enable ACCESS_FINE_LOCATION and ACCESS_COARSE_LOCATION in Sketchware > Permission manager.
		
		// What to do once permission is granted (and GPS is on)
		final Runnable onLocationGranted = new Runnable() {
			@Override public void run() {
				android.location.LocationManager lm =
				(android.location.LocationManager) getSystemService(Context.LOCATION_SERVICE);
				boolean on = lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)
				|| lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER);
				if (!on) {
					new android.app.AlertDialog.Builder(DashActivity.this)
					.setTitle("Turn on location")
					.setMessage("Location is switched off. Please turn it on to continue.")
					.setPositiveButton("Open settings", new android.content.DialogInterface.OnClickListener() {
						@Override public void onClick(android.content.DialogInterface d, int w) {
							startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
						}
					})
					.setNegativeButton("Cancel", null)
					.show();
					return;
				}
				// TODO: put your code that uses location here
				Toast.makeText(getApplicationContext(), "Location ready", Toast.LENGTH_SHORT).show();
			}
		};
		
		// Receives the user's answer from the system permission dialog
		final androidx.activity.result.ActivityResultLauncher<String[]> locationLauncher =
		registerForActivityResult(
		new androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions(),
		new androidx.activity.result.ActivityResultCallback<java.util.Map<String, Boolean>>() {
			@Override public void onActivityResult(java.util.Map<String, Boolean> res) {
				boolean fine = Boolean.TRUE.equals(res.get(android.Manifest.permission.ACCESS_FINE_LOCATION));
				boolean coarse = Boolean.TRUE.equals(res.get(android.Manifest.permission.ACCESS_COARSE_LOCATION));
				if (fine || coarse) {            // coarse only = user chose "Approximate" (Android 12+)
					onLocationGranted.run();
				} else if (!shouldShowRequestPermissionRationale(android.Manifest.permission.ACCESS_FINE_LOCATION)) {
					// Denied with "Don't ask again": only the app settings page can fix it
					new android.app.AlertDialog.Builder(DashActivity.this)
					.setTitle("Location permission needed")
					.setMessage("Please allow Location in the app settings.")
					.setPositiveButton("Open settings", new android.content.DialogInterface.OnClickListener() {
						@Override public void onClick(android.content.DialogInterface d, int w) {
							startActivity(new Intent(
							android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
							android.net.Uri.parse("package:" + getPackageName())));
						}
					})
					.setNegativeButton("Cancel", null)
					.show();
				} else {
					Toast.makeText(getApplicationContext(), "Location permission denied.", Toast.LENGTH_LONG).show();
				}
			}
		});
		
		// Call this whenever you need location (button click, screen start, etc.)
		final Runnable requestLocation = new Runnable() {
			@Override public void run() {
				boolean fine = androidx.core.content.ContextCompat.checkSelfPermission(
				DashActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION)
				== android.content.pm.PackageManager.PERMISSION_GRANTED;
				boolean coarse = androidx.core.content.ContextCompat.checkSelfPermission(
				DashActivity.this, android.Manifest.permission.ACCESS_COARSE_LOCATION)
				== android.content.pm.PackageManager.PERMISSION_GRANTED;
				if (fine || coarse) {
					onLocationGranted.run();
				} else {
					locationLauncher.launch(new String[]{
						android.Manifest.permission.ACCESS_FINE_LOCATION,
						android.Manifest.permission.ACCESS_COARSE_LOCATION});
				}
			}
		};
		
		// Ask for location as soon as the dashboard opens
		requestLocation.run();
		// ============ Pick parent from contacts, with runtime READ_CONTACTS permission ============
		// Put in DashActivity onCreate. Also enable READ_CONTACTS in Sketchware > Permission manager.
		final EditText etPhone = findViewById(R.id.edittext5);
		final TextView tvContact = findViewById(R.id.tv_contact_label);
		
		// 1) Result of the contact list screen
		final androidx.activity.result.ActivityResultLauncher<Intent> contactLauncher =
		registerForActivityResult(
		new androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult(),
		new androidx.activity.result.ActivityResultCallback<androidx.activity.result.ActivityResult>() {
			@Override public void onActivityResult(androidx.activity.result.ActivityResult result) {
				if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
				android.net.Uri uri = result.getData().getData();
				if (uri == null) return;
				android.database.Cursor c = null;
				try {
					c = getContentResolver().query(uri, new String[]{
						android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
						android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER},
					null, null, null);
					if (c != null && c.moveToFirst()) {
						String name = c.getString(0);
						String num = c.getString(1);
						if (num != null) num = num.replaceAll("[\\s\\-()]", "");
						etPhone.setText(num);
						tvContact.setText(name != null ? name : "Contact selected");
					}
				} catch (Exception e) {
					Toast.makeText(getApplicationContext(), "Could not read the contact.", Toast.LENGTH_SHORT).show();
				} finally {
					if (c != null) c.close();
				}
			}
		});
		
		final Runnable openContacts = new Runnable() {
			@Override public void run() {
				contactLauncher.launch(new Intent(Intent.ACTION_PICK,
				android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI));
			}
		};
		
		// 2) Result of the permission dialog
		final androidx.activity.result.ActivityResultLauncher<String> contactPermLauncher =
		registerForActivityResult(
		new androidx.activity.result.contract.ActivityResultContracts.RequestPermission(),
		new androidx.activity.result.ActivityResultCallback<Boolean>() {
			@Override public void onActivityResult(Boolean granted) {
				if (granted) {
					openContacts.run();
				} else if (!shouldShowRequestPermissionRationale(android.Manifest.permission.READ_CONTACTS)) {
					// Denied with "Don't ask again": only the app settings can fix it
					new android.app.AlertDialog.Builder(DashActivity.this)
					.setTitle("Contacts permission needed")
					.setMessage("Allow Contacts in the app settings to pick the parent\u2019s number.")
					.setPositiveButton("Open settings", new android.content.DialogInterface.OnClickListener() {
						@Override public void onClick(android.content.DialogInterface d, int w) {
							startActivity(new Intent(
							android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
							android.net.Uri.parse("package:" + getPackageName())));
						}
					})
					.setNegativeButton("Cancel", null)
					.show();
				} else {
					Toast.makeText(getApplicationContext(),
					"Contacts permission denied. You can still type the number.", Toast.LENGTH_LONG).show();
				}
			}
		});
		
		// 3) Tap the button: check permission first, ask only if needed
		findViewById(R.id.btn_pick_contact).setOnClickListener(new View.OnClickListener() {
			@Override public void onClick(View v) {
				if (androidx.core.content.ContextCompat.checkSelfPermission(
				DashActivity.this, android.Manifest.permission.READ_CONTACTS)
				== android.content.pm.PackageManager.PERMISSION_GRANTED) {
					openContacts.run();
				} else {
					contactPermLauncher.launch(android.Manifest.permission.READ_CONTACTS);
				}
			}
		});
		// ============ Dash UI setup: put in DashActivity onCreate, AFTER setContentView / initialize ============
		// Sketchware's designer can reset icons to "default_image" and drop hints. Setting them in code always wins.
		
		// Hints + helper text
		((com.google.android.material.textfield.TextInputLayout) findViewById(R.id.textinputlayout5)).setHint("School name");
		((com.google.android.material.textfield.TextInputLayout) findViewById(R.id.textinputlayout6)).setHint("Parent\u2019s phone number");
		((com.google.android.material.textfield.TextInputLayout) findViewById(R.id.textinputlayout6))
		.setHelperText("Include the country code, e.g. +233 24 123 4567");
		((com.google.android.material.textfield.TextInputLayout) findViewById(R.id.textinputlayout7)).setHint("Child\u2019s name");
		
		// Field icons
		((com.google.android.material.textfield.TextInputLayout) findViewById(R.id.textinputlayout5)).setStartIconDrawable(R.drawable.ic_school);
		((com.google.android.material.textfield.TextInputLayout) findViewById(R.id.textinputlayout6)).setStartIconDrawable(R.drawable.ic_phone);
		((com.google.android.material.textfield.TextInputLayout) findViewById(R.id.textinputlayout7)).setStartIconDrawable(R.drawable.ic_person);
		
		// Button icons
		final ImageView icContact = findViewById(R.id.img_contact);
		icContact.setImageResource(R.drawable.ic_contacts);
		icContact.setColorFilter(Color.parseColor("#40A8F6"));
		
		final ImageView icQr = findViewById(R.id.imageview4);
		icQr.setImageResource(R.drawable.ic_qr_code);
		icQr.setColorFilter(Color.WHITE);
		
		final ImageView icScan = findViewById(R.id.imageview5);
		icScan.setImageResource(R.drawable.ic_qr_scan);
		icScan.setColorFilter(Color.parseColor("#40A8F6"));
		binding.tvBrand.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_bold.ttf"), 1);
		binding.heading.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_bold.ttf"), 1);
		binding.sub.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.edittext4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.edittext5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.tvContactLabel.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.edittext6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
		binding.textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_regular.ttf"), 0);
	}
	
}